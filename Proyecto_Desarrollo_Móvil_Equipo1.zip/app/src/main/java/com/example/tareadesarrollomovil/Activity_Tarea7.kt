package com.example.tareadesarrollomovil

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Activity_Tarea7 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tarea7)
    }
}